import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';

const listImg = [
	"logo_dvfu.png",
	"logo_imct.png"
]

const listProf1 = [
	{
		prof: "Web-разработчиков",
		discr: `Создают сложные и очень сложные сайты. Продумывают, чтобы пользователям было быстро и удобно.`
	},
	{
		prof: "Гейм-девелоперов",
		discr: `Создают видеоигры. Погружают всех нас в новые миры.`
	},
	{
		prof: "AI/ML-cпециалистов",
		discr: `Используют в деле искусственный интеллект и машинное обучение. Фактами и прогнозами делает бизнесу хорошо.`
	},
	{
		prof: "Аналитиков данных",
		discr: `С помощью чисел решают, куда двигаться компаниям. Помогают бизнесу получать еще больше денег.`
	},
	{
		prof: "Мобильных разработчиков",
		discr: `Создают мобильные приложения, которые найдут тебя везде. Умещают на маленьких экранах максимальный функционал.`
	}
]

const listProf2 = [
	{
		prof: "Веб-разработка",
		discr: `Создает сложные и очень сложные сайты.`
	},
	{
		prof: "Гейм-девелоперов",
		discr: `Создает видеоигры для гостиных и карманов.`
	},
	{

		prof: "AI/ML-специалисты",
		discr: `Использует в деле искусственный интеллект и машинное обучение.`
	},
	{
		prof: "Аналитика данных",
		discr: `С помощью чисел решает, куда двигаться компаниям.`
	},
	{
		prof: "Мобильная разработка",
		discr: `Создает мобильные приложения, которые найдут тебя везде.`
	}
]


function Head(props) {
	const logoImages = listImg.map((img, index) =>
		<img key={index} src={img} />
	);
	return(
		<div className="head">
			{logoImages}
		</div>
	);
};

function Tagline(props) {
	if (props.__id == 0) {
		return(
			<h1>
				Хватит уже игр, <br/> пора <br/> разрабатывать и зарабатывать
			</h1>
		)
	}
	if (props.__id == 1) {
		return(
			<h1>
				Давай учиться вместе
			</h1>
		)
	}
}

function Button_1(props) {
	function Click() {
		if (props.value === "Хочу учиться!") {
			props.func(1);
		}
		else {
			props.func(0);
		}
	}

	return (
		<input className="button" type="button" value={props.value} onClick={Click} />
	)
}

function Button_2(props) {
	function Click() {
		props.func(2);
		props.click_b2(props.title_page);
	}


	return (
		<input className="button__minis" type="button" value={props.value} onClick={Click} / >
	)
}

function ProfItem(props) {
	const [isOpen, setOpenClose] = React.useState(false);

	const press = () => {
		setOpenClose(!isOpen);
	}

	return (
		<li onClick={press}>
			<span className="left">{props.prof}</span>
			<span className="right">{isOpen ? "×" : "+"}</span>
			{isOpen &&
				<>
					<p>{props.discr}</p>
					<Button_2 value={"Отправить"} func={props.click_b1} title_page={props.prof} click_b2={props.click_b2} />
				</>
			}
		</li>
	)
}

function Professions_1 (props) {
	const listProf = props.list.map((item, index) =>
		<ProfItem key={index} prof={item.prof} discr={item.discr} page={props.page} click_b1={props.click_b1} click_b2={props.click_b2} />
	);

	return (
		<div className="prof">
			<h2>{props.title} </h2>
			<ul>
				{listProf}
			</ul>
		</div>
	)
}

function Professions_2 (props) {
	return (
		<div className="prof">
			<h2>{props.title}: {props.titlePafe}</h2>
		</div>
	)
}

function IMG (props) {
	return(
		<div className="img">
			<img src={props.img} />
		</div>
	);
}



function Content() {
	const [numPage, updateNumPage] = React.useState(0);
	const [titlePafe, updateTitlePafe] = React.useState("Main");

	switch (numPage) {
		case 0:
			return (
				<>
					<Head />
					<Tagline __id={"0"} />
					<Button_1 value={"Хочу учиться!"} func={updateNumPage} />
					<Professions_1 title="Обучаем на:" list={listProf1} click_b1={updateNumPage} click_b2={updateTitlePafe} />
				</>
			)
			break;
		case 1:
			return(
				<>
					<Head />
					<Tagline __id={"0"} />
					<Button_1 value={"Обратно"} func={updateNumPage} />
					<Professions_1 title="Выбирай программу: Диджитал — это ты" list={listProf2} click_b1={updateNumPage} click_b2={updateTitlePafe} />
				</>
			)
			break;
		case 2:
			return(
				<>
					<Head />
					<Tagline __id={"1"} />
					<Professions_2 title="Заявка принята" titlePafe={titlePafe} click_b1={updateNumPage} />
					<IMG img="img1.png" />
					<Button_1 value={"Обратно"} func={updateNumPage} />
				</>
			)
			break;
	}
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<Content />);