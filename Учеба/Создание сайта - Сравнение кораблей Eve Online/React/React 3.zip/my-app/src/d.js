










 
function Professions (props) {
	
	const listProf = props.list.map((item, index) =>
	<ProfItem key={index} prof={item.prof} discr={item.discr} />
	
	);
	return (
	<div className="prof">
		<h2>{props.title} </h2>
		<ul>
			{listProf}	
		</ul>
	</div>
	
	)
}

function ProfItem(props) {

	const [isOpen, setOpenClose] = React.useState(false);
	const press = () => {
	setOpenClose(!isOpen);
	}
	return(
	<li onClick={press}>
	<span className="left">{props.prof}</span>
	<span className="right">{isOpen ? "×" : "+"}</span>
	{isOpen &&
	<p> {props.discr}</p>
	}
	</li>
	) 
}
